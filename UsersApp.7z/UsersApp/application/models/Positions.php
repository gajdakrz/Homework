<?php 
class Positions extends CI_Model{
    function __construct() {
    parent::__construct();
    $this->load->database();
    }
    public function load() {
        $query = $this->db->get('positions');
        return $query->result_array();
    }
}