<?php 
class Users extends CI_Model{
    function __construct() {
    parent::__construct();
    $this->load->database();
    }
    public function load() {
        $sql = "
            SELECT
            u.id,
            u.first_name,
            u.last_name,
            u.email,
            u.description,
            u.id_position,
            u.1_info,
            u.2_info,
            u.3_info,
            u.created_dt,
            u.modified_dt,
            p.title
            FROM
            users u, positions p
            WHERE
            u.id_position = p.id
            ";
        
        $query = $this->db->query($sql);
        return $query->result_array();
    }
    
    public function insert() {
        $data = 
        [ 
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'email' => $this->input->post('email'),
            'description' => $this->input->post('description'),
            'id_position' => $this->input->post('position'),
            '1_info' => $this->input->post('1_info'),
            '2_info' => $this->input->post('2_info'),
            '3_info' => $this->input->post('3_info')
        ];
        
    try
    {        
        $this->db->insert('users', $data);
        $id = $this->db->insert_id();
        if(isset($id))
            {
            return array(
                'status' => 'success',
                'opis' => 'Użytkownik dodany');
            }
        
    }
        catch (PDOException $e)
        {   
            return array(
            'status' => 'error',
            'opis' => 'Użytkownik niedodany: ' . $e->getMessage());
            
        }
    }
    
    public function update() {

        $sql = "
            UPDATE users
            SET
            first_name = ?,
            last_name = ?,
            email = ?,
            description = ?,
            id_position = ?,
            1_info = ?,
            2_info = ?,
            3_info = ?
            FROM
            users
            WHERE
            u.id = ?
            ";
        
        $data = 
        [ 
            'first_name' => $this->input->post('firstname'),
            'last_name' => $this->input->post('lastname'),
            'email' => $this->input->post('email'),
            'description' => $this->input->post('description'),
            'id_position' => $this->input->post('position'),
            '1_info' => $this->input->post('1_info'),
            '2_info' => $this->input->post('2_info'),
            '3_info' => $this->input->post('3_info')
        ];
        
        try
        { 
            $this->db->where('id', $this->input->post('id'));
            $this->db->update('users', $data);
            return array(
            'status' => 'success',
            'opis' => 'Użytkownik zmieniony');
        }
        catch (PDOException $e)
        {   
            return array(
            'status' => 'error',
            'opis' => 'Użytkownik niezmieniony: ' . $e->getMessage());
            
        }
    }
    
    public function delete($id) {
        try
        { 
            $data  = ['id' => $id];
            $this->db->delete('users', $data);
            
            $sql = "
            SELECT u.id
            FROM
            users u
            WHERE
            u.id = ?
            ";
        
        $query = $this->db->query($sql, $data);
        $deletedid = $query->result_array();

        if(count($deletedid)<=0)
            {
            return array(
                'status' => 'success',
                'opis' => 'Użytkownik usunięty');
            }
        }
        catch (PDOException $e)
        {   
            return array(
            'status' => 'error',
            'opis' => 'Użytkownik nieusunięty: ' . $e->getMessage());
            
        }
    }
}