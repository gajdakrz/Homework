<?php

class Emails extends CI_Model {

    function __construct() {
        parent:: __construct();
        $this->load->helper('url');
    }

    public function prepare() {

        $subject = 'Potwierdzenie rejestracji';
        $html = 'Witaj!<br><br>
                    Dziękuję za rejestrację. To twoje dane:<br>
                    ';
        $html .= 'Imię: ' .$this->input->post('firstname'). '<br>';
        $html .= 'Nazwisko: ' .$this->input->post('firstname'). '<br>';
        $html .= 'email: ' .$this->input->post('email'). '<br>';
        if($this->input->post('position') == 1)
        {
            $html .= 'Pozycja: Tester<br>';
            $html .= '&nbsp; Systemy testujące: ' .$this->input->post('1_info'). '<br>';
            $html .= '&nbsp; Systemy raportowe: ' .$this->input->post('2_info'). '<br>';
            $html .= '&nbsp; Zna Selenium: ' .$this->input->post('3_info'). '<br>';
        }
        elseif($this->input->post('position') == 2)
        {
            $html .= 'Pozycja: Developer<br>';
            $html .= '&nbsp; Środowiska ide: ' .$this->input->post('1_info'). '<br>';
            $html .= '&nbsp; Języki programowania: ' .$this->input->post('2_info'). '<br>';
            $html .= '&nbsp; Zna Mysql: ' .$this->input->post('3_info'). '<br>';
        }
        elseif($this->input->post('position') == 3)
        {
            $html .= 'Pozycja: Project manager<br>';
            $html .= '&nbsp; Metodologie prowadzenia projektów: ' .$this->input->post('1_info'). '<br>';
            $html .= '&nbsp; Systemy raportowe: ' .$this->input->post('2_info'). '<br>';
            $html .= '&nbsp; Zna Scrum: ' .$this->input->post('3_info'). '<br>';
        }
        $html .= 'Opis: ' .$this->input->post('description'). '<br><br>';
        $html .= 'Pozdrawiam,<br>
                  Krzysztof Gajda
                  ';
        return $this->send($subject, $html);
    }

    public function send($subject, $message) {
        $this->load->config('email');
        $this->load->library('email');
        
        $from = $this->config->item('smtp_user');
        $to = $this->input->post('email');

        $this->email->set_newline("\r\n");
        $this->email->from($from);
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($message);

        if ($this->email->send()) {
            return array(
            'status' => true,
            'opis' => 'Użytkownik dodany i mail wysłany');
        } else {
            return array(
            'status' => false,
            'opis' => 'Użytkownik dodany i mail niewysłany' . $this->email->print_debugger());
        }
    }
}