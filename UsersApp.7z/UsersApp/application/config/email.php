<?php  
defined('BASEPATH') OR exit('No direct script access allowed');

$config = array
(
    'protocol' => 'smtp', // 'mail', 'sendmail', or 'smtp'
    'smtp_host' => 'ssl://smtp.gmail.com', 
    'smtp_port' => 465,
    'smtp_user' => 'gajda.krzysztof@gmail.com', //This is example for gmail server. Insert propper
    'smtp_pass' => 'password', //This is example. Insert proper
    'mailtype' => 'html', //plaintext 'text' mails or 'html'
    'smtp_timeout' => '4', //in seconds
    'charset' => 'utf-8',
    'newline' => "\r\n",
    'wordwrap' => TRUE
);