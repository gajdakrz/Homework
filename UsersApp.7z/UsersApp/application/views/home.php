<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Strona domowa użytkownika">
    <meta name="author" content="Krzysztof Gajda">
    <link href="<?php echo base_url().'assets/bootstrap/css/bootstrap.min.css';?>" rel="stylesheet">
    <title>Użytkownik</title>
</head>
<body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script type="text/javascript">
    function posSelectCheck(nameSelect)
{
    if(nameSelect){
        if(nameSelect.value == 1){
            document.getElementById("test").style.display = "";
            document.getElementById("dev").style.display = "none";
            document.getElementById("pm").style.display = "none";
            document.getElementById('1_info_test').disabled = false;
            document.getElementById('2_info_test').disabled = false;
            document.getElementById('3_info_test').disabled = false;
            document.getElementById('1_info_dev').disabled = true;
            document.getElementById('2_info_dev').disabled = true;
            document.getElementById('3_info_dev').disabled = true;
            document.getElementById('1_info_pm').disabled = true;
            document.getElementById('2_info_pm').disabled = true;
            document.getElementById('3_info_pm').disabled = true;
        }
        else if(nameSelect.value == 2){
            document.getElementById("test").style.display = "none";
            document.getElementById("dev").style.display = "";
            document.getElementById("pm").style.display = "none";
            document.getElementById('1_info_test').disabled = true;
            document.getElementById('2_info_test').disabled = true;
            document.getElementById('3_info_test').disabled = true;
            document.getElementById('1_info_dev').disabled = false;
            document.getElementById('2_info_dev').disabled = false;
            document.getElementById('3_info_dev').disabled = false;
            document.getElementById('1_info_pm').disabled = true;
            document.getElementById('2_info_pm').disabled = true;
            document.getElementById('3_info_pm').disabled = true;
        }
        else if(nameSelect.value == 3){
            document.getElementById("test").style.display = "none";
            document.getElementById("dev").style.display = "none";
            document.getElementById("pm").style.display = "";
            document.getElementById('1_info_test').disabled = true;
            document.getElementById('2_info_test').disabled = true;
            document.getElementById('3_info_test').disabled = true;
            document.getElementById('1_info_dev').disabled = true;
            document.getElementById('2_info_dev').disabled = true;
            document.getElementById('3_info_dev').disabled = true;
            document.getElementById('1_info_pm').disabled = false;
            document.getElementById('2_info_pm').disabled = false;
            document.getElementById('3_info_pm').disabled = false;
        }
    }
    else{
        document.getElementById("test").style.display = "none";
        document.getElementById("dev").style.display = "none";
        document.getElementById("pm").style.display = "none";
        document.getElementById('1_info_test').disabled = true;
        document.getElementById('2_info_test').disabled = true;
        document.getElementById('3_info_test').disabled = true;
        document.getElementById('1_info_dev').disabled = true;
        document.getElementById('2_info_dev').disabled = true;
        document.getElementById('3_info_dev').disabled = true;
        document.getElementById('1_info_pm').disabled = true;
        document.getElementById('2_info_pm').disabled = true;
        document.getElementById('3_info_pm').disabled = true;
    }
}

function save()
{
    var len_firstname = document.getElementById("firstname").value.length;
    var len_lastname = document.getElementById("lastname").value.length;
    var len_email = document.getElementById("email").value.length;
    var len_description = document.getElementById("description").value.length;
    var position = document.getElementById("position").value;
    
    if (position == 1)
    {
        var len_info1 = document.getElementById("1_info_test").value.length;
        var len_info2 = document.getElementById("2_info_test").value.length;
        var checked_3_info = document.getElementById("3_info_test").checked;
        var info1_txt = 'Systemy testujące';
        var info2_txt = 'Systemy raportowe';
    }
    else if (position == 2)
    {
        var len_info1 = document.getElementById("1_info_dev").value.length;
        var len_info2 = document.getElementById("2_info_dev").value.length;
        var checked_3_info = document.getElementById("3_info_dev").checked;
        var info1_txt = 'Środowiska ide';
        var info2_txt = 'Języki programowania';
    }
    else if (position == 3)
    {
        var len_info1 = document.getElementById("1_info_pm").value.length;
        var len_info2 = document.getElementById("2_info_pm").value.length;
        var checked_3_info = document.getElementById("3_info_pm").checked;
        var info1_txt = 'Metodologie prowadzenia projektów';
        var info2_txt = 'Systemy raportowe';
    }
    
    if (checked_3_info === true)
    {
        document.getElementById("3_info_val").value = 'T';
    }
    else
    {
        document.getElementById("3_info_val").value = 'N';
    }
    
    check_empty = len_firstname*len_lastname*len_email*len_description*len_info1*len_info2;
    
    if(check_empty > 0)
    {
        document.getElementById('form').submit();
    }
    else
    {
        txt = "";
        if (len_firstname === 0)
        {txt += "Imię\n";}
        if (len_lastname === 0)
        {txt += "Nazwisko\n";}
        if (len_email === 0)
        {txt += "Email\n";}
        if (len_description === 0)
        {txt += "Opis\n";}
        if (len_info1 === 0)
        {txt += info1_txt+"\n";}
        if (len_info2 === 0)
        {txt += info2_txt+"\n";}
        
        alert("Uzupełnij brakujące dane:\n"+txt);
    }    
}

</script>
    <a href = "<?php echo base_url();?>">Home</a> | <a href = "<?php echo site_url("HomeController/admin");?>">Admin</a>
    <h3 class="text-center">Dodanie użytkownika</h3>
    <?php if($this->session->flashdata('success')){ ?>
    <div class="alert alert-success">
        <?php echo $this->session->flashdata('success');?>
    </div>
    <?php }?>
    <?php if($this->session->flashdata('error')){ ?>
    <div class="alert alert-danger">
    <?php echo $this->session->flashdata('error');?>
    </div>
    <?php }?>
    <div align="center">
    <form method="post" id="form" action="index.php/HomeController/save" enctype="multipart/form-data">
    <div class="form-group">
      <label for="example-text-input" class="col-2 col-form-label">Imię</label>
      <div class="col-5">
        <input class="form-control" type="text" value="" id="firstname" name="firstname" >
      </div>
    </div>
    <div class="form-group">
      <label for="example-text-input" class="col-2 col-form-label">Nazwisko</label>
      <div class="col-5">
        <input class="form-control" type="text" value="" id="lastname" name="lastname" >
      </div>
    </div>    
    <div class="form-group">
      <label for="example-email-input" class="col-2 col-form-label">Email</label>
      <div class="col-5">
        <input class="form-control" type="email" value="" id="email" name="email" >
      </div>
    </div>
      <div class="form-group">
        <label for="exampleSelect1" class="col-2 col-form-label">Pozycja</label>
        <div class="col-5">
        <select class="form-control" onchange="posSelectCheck(this);" name="position" id="position">
          <?php foreach($positions as $row) { ?>
             <option value="<?php echo $row['id'];?>"> <?php echo $row['title'];?></option>
          <?php } ?>
        </select>
        </div>
      </div>

        <div class="form-group" id="test">
            <label for="example-email-input" class="col-2 col-form-label">Systemy testujące</label>
            <div class="col-4">
            <input class="form-control" type="text" value="" id="1_info_test" name="1_info" >
            </div>
            <label for="example-email-input" class="col-2 col-form-label">Systemy raportowe</label>
            <div class="col-4">
            <input class="form-control" type="text" value="" id="2_info_test" name="2_info" >
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="3_info_test">
                <label class="form-check-label" for="defaultCheck1">Zna Selenium</label>        
            </div>
        </div>
        <div class="form-group" id="dev" style="display:none;">
            <label for="example-email-input" class="col-2 col-form-label">Środowiska ide</label>
            <div class="col-4">
            <input class="form-control" type="text" value="" id="1_info_dev" name="1_info" disabled>
            </div>
            <label for="example-email-input" class="col-2 col-form-label">Języki programowania</label>
            <div class="col-4">
            <input class="form-control" type="text" value="" id="2_info_dev" name="2_info" disabled>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="3_info_dev" disabled>
                <label class="form-check-label" for="defaultCheck1">Zna Mysql</label>        
            </div>
        </div>
        <div class="form-group" id="pm" style="display:none;">
            <label for="example-email-input" class="col-2 col-form-label">Metodologie prowadzenia projektów</label>
            <div class="col-4">
            <input class="form-control" type="text" value="" id="1_info_pm" name="1_info" disabled>
            </div>
            <label for="example-email-input" class="col-2 col-form-label">Systemy raportowe</label>
            <div class="col-4">
            <input class="form-control" type="text" value="" id="2_info_pm" name="2_info" disabled>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="3_info_pm" disabled>
                <label class="form-check-label" for="defaultCheck1">Zna Scrum</label>        
            </div>
        </div>
        <input type='hidden' name='3_info' id='3_info_val'>
      <div class="form-group">
        <label for="exampleTextarea" class="col-2 col-form-label">Opis</label>
        <div class="col-5">
        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
        </div>
      </div>
      <button type="button" class="btn btn-primary btn-lg" onclick="save()">Zapisz</button>
    </form>
    </div>
</body>
</html>