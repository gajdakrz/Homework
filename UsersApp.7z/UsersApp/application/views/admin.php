<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Strona administracyjna">
    <meta name="author" content="Krzysztof Gajda">
    <link href="<?php echo base_url().'assets/bootstrap/css/bootstrap.min.css';?>" rel="stylesheet">
    <title>Admin</title>
</head>
<body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script type="text/javascript">
function change(id)
{
	if(id > 0)
	{
		var firstname = document.getElementById("firstname"+id).value;
		var lastname = document.getElementById("lastname"+id).value;
                var email = document.getElementById("email"+id).value;
                var position = document.getElementById("position"+id).value;
                var description = document.getElementById("description"+id).value;
                var info1 = document.getElementById("1_info"+id).value;
                var info2 = document.getElementById("2_info"+id).value;
                var info3 = document.getElementById("3_info"+id).value;

            var uri = "change";
		var dat = 
                    {
                        "id": id, 
                        "firstname": firstname,
                        "lastname": lastname,
                        "email": email,
                        "position": position,
                        "description": description,
                        "1_info": info1,
                        "2_info": info2,
                        "3_info": info3
                    };
 
		$.post(uri, dat, function(data,status){
                      window.location.reload(true)
                    });   
        }
}
</script>

    <a href = "<?php echo base_url();?>">Home</a> | <a href = "<?php echo site_url("HomeController/admin");?>">Admin</a>
    <h3 class="text-center">Panel administracyjny</h3>
    <?php if($this->session->flashdata('success')){ ?>
    <div class="alert alert-success">
        <?php echo $this->session->flashdata('success');?>
    </div>
    <?php }?>
    <?php if($this->session->flashdata('error')){ ?>
    <div class="alert alert-danger">
    <?php echo $this->session->flashdata('error');?>
    </div>
    <?php }?>
    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Imię</th>
          <th scope="col">Nazwisko</th>
          <th scope="col">email</th>
          <th scope="col">Stopień</th>
          <th scope="col">Info 1</th>
          <th scope="col">Info 2</th>
          <th scope="col">Info 3</th>
          <th scope="col">Opis</th>
          <th scope="col">Data utworzenia</th>
          <th scope="col">Data modyfikacji</th>
          <th scope="col">Operacje</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($users as $row) { ?>
        <tr>
            <td><?php echo $row['id'];?></td>
            <td><input class="form-control" type="text" value="<?php echo $row['first_name'];?>" id="firstname<?php echo $row['id'];?>" name="firstname" ></td>
            <td><input class="form-control" type="text" value="<?php echo $row['last_name'];?>" id="lastname<?php echo $row['id'];?>" name="lastname" ></td>
            <td><input class="form-control" type="text" value="<?php echo $row['email'];?>" id="email<?php echo $row['id'];?>" name="email" ></td>
            <td>
                <select class="form-control" name="position" id="position<?php echo $row['id'];?>">
                <?php foreach($positions as $pos) { ?>
                   <option value="<?php echo $pos['id'];?>" <?php if($pos['id'] == $row['id_position']) {echo 'selected' ;}?>><?php echo $pos['title'];?></option>
                <?php } ?>
                </select>
            </td>
            <td><input class="form-control" type="text" value="<?php echo $row['1_info'];?>" id="1_info<?php echo $row['id'];?>" name="1_info" ></td>
            <td><input class="form-control" type="text" value="<?php echo $row['2_info'];?>" id="2_info<?php echo $row['id'];?>" name="2_info" ></td>
            <td>
                <select name="3_info" id="3_info<?php echo $row['id'];?>">
                    <option value="T" <?php if($row['3_info'] == 'T') {echo 'selected' ;}?>>T</option>
                    <option value="N" <?php if($row['3_info'] == 'N') {echo 'selected' ;}?>>N</option>
                </select>
            </td>
            <td><textarea class="form-control" id="description<?php echo $row['id'];?>" name="description" rows="3"><?php echo $row['description'];?></textarea></td>
            <td><?php echo $row['created_dt'];?></td>
            <td><?php echo $row['modified_dt'];?></td>
            <td>
                <button type="button" class="btn btn-success" onclick="change('<?php echo $row['id']?>')">Zapisz</button>
                <button type="button" class="btn btn-danger" onclick="if(confirm('Czy usunąć?')) window.location='<?php echo site_url("HomeController/remove/");echo $row['id']?>'">Usuń</button>
            </td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
</body>
</html>