<?php

class HomeController extends CI_Controller{
    
    function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Users');
        $this->load->model('Positions');
        $this->load->model('Emails');
    }
    
    public function index(){
        $position['positions'] = $this->Positions->load();
        $this->load->view('home', $position);
    }
    public function admin(){
        $data['users'] = $this->Users->load();
        $data['positions'] = $this->Positions->load();
        $this->load->view('admin', $data);
    }
    
    public function save(){
        $konto = $this->Users->insert();
        if ($konto['status'] == 'success')
        {
            $email = $this->Emails->prepare();
            if ($email['status'] == 'success')
            {
                $msg = $email['opis'];
            }
            else 
            {
                $msg = $konto['opis'];
            }
        }
        else 
        {
            $msg = $konto['opis'];
        }
        $status = $konto['status'];
        $this->sendMsg($msg, $status, 'index');
    }
    
    public function change(){
        $konto = $this->Users->update();
        $msg = $konto['opis'];
        $status = $konto['status'];
        $this->sendMsg($msg, $status, 'admin');
    }
    
    public function remove($id){
        $konto = $this->Users->delete($id);
        $msg = $konto['opis'];
        $status = $konto['status'];
        $this->sendMsg($msg, $status, 'admin');
    }
    
    public function sendMsg($msg, $status, $page)
    {
      $this->session->set_flashdata($status, $msg);
      if($page == 'admin')
        {
        $this->admin();
        }
        else 
        {
        $this->index();    
}
    }
}
?>